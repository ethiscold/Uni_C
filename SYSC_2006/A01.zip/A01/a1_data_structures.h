/********* a1_data_structures.h ********
	
	Student Name 	= Ethan Robitaille 
	Student Number	= 101233797
*/

/********** DON'T MODIFY **********/
typedef struct milestone {
    char name[100];
    float cost, time;
    unsigned short int num_employees;
    _Bool completed;
}milestone_t;